package review;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


// 게시판 서블릿 
public class ReviewController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String RequestURI = request.getRequestURI(); // 파일의 경로 path
		String contextPath = request.getContextPath(); // 프로젝트 경로 path
		// 총 파일경로에서 프로젝트 경로를 뺀 path
		// 예: http://localgost:8010/WebMarket (/BoardListAction.do)
		String command = RequestURI.substring(contextPath.length()); // substring: 잘라내기
		
		response.setContentType("text/html; charset=utf-8");
		request.setCharacterEncoding("utf-8");
		 		
		
		
			if (command.equals("/MyReviewList.jsp.review")) { //마이 리뷰 관리 리스트
		 		RequestDispatcher rd = request.getRequestDispatcher("/MyReviewList.jsp");
				rd.forward(request, response);				
	 	} else if (command.equals("/MyReviewEditAction.review")) {//마이 리뷰 선택된 글 상세 페이지 가져오기
				requestReviewEdit(request);
				RequestDispatcher rd = request.getRequestDispatcher("/MyReviewEdit.review");
				rd.forward(request, response);						
		} else if (command.equals("/MyReviewEdit.review")) { //마이 리뷰 글 상세 페이지 출력하기
				RequestDispatcher rd = request.getRequestDispatcher("/MyReviewEdit.jsp");
				rd.forward(request, response);	
		} else if (command.equals("/MyReviewUpdateAction.review")) { //마이 리뷰 선택된 글의 수정
				requestReviewUpdate(request);
				RequestDispatcher rd = request.getRequestDispatcher("/MyReviewList.jsp");
				rd.forward(request, response);
		} else if (command.equals("/MyReviewDeleteAction.review")) { //마이 리뷰 선택된 글 삭제하기
				requestReviewDelete(request);
				RequestDispatcher rd = request.getRequestDispatcher("/MyReviewList.jsp");
				rd.forward(request, response);				
		} else if (command.equals("/AdminReviewList.jsp.review")) { //관리자 리뷰 관리 리스트
				RequestDispatcher rd = request.getRequestDispatcher("/AdminReviewList.jsp");
				rd.forward(request, response);				
		} else if (command.equals("/AdminReviewEditAction.review")) {//관리자가 선택한 글 상세 페이지 가져오기
				requestReviewEdit(request);
				RequestDispatcher rd = request.getRequestDispatcher("/AdminReviewEdit.review");
				rd.forward(request, response);						
		} else if (command.equals("/AdminReviewEdit.review")) { //관리자가 선택한 글 상세 페이지 출력하기
				RequestDispatcher rd = request.getRequestDispatcher("/AdminReviewEdit.jsp");
				rd.forward(request, response);	
		} else if (command.equals("/AdminReviewUpdateAction.review")) { //관리자가 선택한 글의 수정
				requestReviewUpdate(request);
				RequestDispatcher rd = request.getRequestDispatcher("/AdminReviewList.jsp");
				rd.forward(request, response);
		} else if (command.equals("/AdminReviewDeleteAction.review")) { //관리자가 선택한 글 삭제하기
				requestReviewDelete(request);
				RequestDispatcher rd = request.getRequestDispatcher("/AdminReviewList.jsp");
				rd.forward(request, response);				
		} 
	}


	//선택된 글 상세 페이지 가져오기
	public void requestReviewEdit(HttpServletRequest request){
					
		ReviewDAO dao = new ReviewDAO();
		int num = Integer.parseInt(request.getParameter("num"));
		int pageNum = Integer.parseInt(request.getParameter("pageNum"));	
		
		Review Review = new Review();
		Review = dao.getReviewByNum(num, pageNum);		
		
		request.setAttribute("num", num);		 
   		request.setAttribute("pageNum", pageNum); 
   		request.setAttribute("Review", Review);   									
	}
	//선택된 글 내용 수정하기
	public void requestReviewUpdate(HttpServletRequest request){
					
		int num = Integer.parseInt(request.getParameter("num"));
		
		ReviewDAO dao = new ReviewDAO();		
		
		Review Review = new Review();		
		Review.setNum(num);
		Review.setContent(request.getParameter("content"));	
		
		
		 dao.updateReview(Review);
	}
	//선택된 글 삭제하기
	public void requestReviewDelete(HttpServletRequest request){
					
		int num = Integer.parseInt(request.getParameter("num"));
		
		ReviewDAO dao = new ReviewDAO();
		dao.deleteReview(num);					
	}
	
	
}
