package review;

import java.sql.*;
import java.util.ArrayList;

public class ReviewDAO {
	
	private Connection conn;
	private ResultSet rs;
	
	public ReviewDAO() { //생성자 생성시 DB연결 conn
		try {
			String url = "jdbc:mysql://localhost:3306/cafe?useSSL=false";
			String user = "root";
			String password = "1234";

			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(url, user, password);	
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}

	//마이 리뷰 개수
	public int getMyCount(String sessionId) {// 매개변수에 세션아이디 추가해야함
		String sql = "select count(*) from review where userid=?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, sessionId);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1; // DB오류
		
	}

	// 해당 상품 리뷰 개수
	public int getCafeCount(String cafeid) {// 매개변수에 카페 아이디 추가 해야함
		String sql = "select count(*) from review where cafeid=?";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, cafeid);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return rs.getInt(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1; // DB오류
		
	}
	
	// 관리자 전체  리뷰 개수
	public int getAllCount() {
		String sql = "select count(*) from review";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return rs.getInt(1);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1; //DB 오류
	}
	
	// 마이 리뷰 리스트
	public ArrayList<Review> getMyReview(int pageNum, String Search, String sessionId){ // 매개변수에 세션아이디 추가해야함
		String sql;
		int count = getMyCount(sessionId);
		int start = (pageNum -1)*5;
		int index = start + 1;
		
		if(Search != null)
			sql = "select review.*,coffee.name from Review,Coffee where Review.cafeid = Coffee.cafeid and userid=? and (content like '%"+Search+"%'or review.regist_day like '%"+Search+"%'or name like'%"+Search+"%'or userid like '%"+Search+"%') order by num desc";
		else 
			sql = "select review.*,coffee.name from Review,Coffee where Review.cafeid = Coffee.cafeid and userid=? order by num desc";
		
		ArrayList<Review> list = new ArrayList<Review>();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, sessionId);
			rs = pstmt.executeQuery();
			while(rs.absolute(index)) {
				Review Review = new Review();
				Review.setNum(rs.getInt(1));
				Review.setUserid(rs.getString(2));
				Review.setContent(rs.getString(3));
				Review.setRegist_day(rs.getString(4));
				Review.setCafeid(rs.getInt(5));
				Review.setCafename(rs.getString(6));
				list.add(Review);
				

					if (index < (start + 5) && index <= count) { 
						index++;
					} else {
						break;
					}
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	
	// 상품 리뷰 리스트
	public ArrayList<Review> getCofeReview(int pageNum,String cafeid){ // 매개변수에 카페아이디 추가해야함
		int count = getCafeCount(cafeid);
		int start = (pageNum -1)*5;
		int index = start + 1;
		
		 String sql = "select * from Review where cafeid=? order by num desc";
		
		ArrayList<Review> list = new ArrayList<Review>();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, cafeid);
			rs = pstmt.executeQuery();
			while(rs.absolute(index)) {
				Review Review = new Review();
				Review.setNum(rs.getInt(1));
				Review.setUserid(rs.getString(2));
				Review.setContent(rs.getString(3));
				Review.setRegist_day(rs.getString(4));
				Review.setCafeid(rs.getInt(5));
				list.add(Review);
				
				if (index < (start + 5) && index <= count) {
					index++;
				} else {
					break;
				}
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	//관리자 리뷰 전체보기 리스트
	public ArrayList<Review> getAllReview(int pageNum, String Search){
		String sql;
		int count = getAllCount();
		int start = (pageNum -1)*12;
		int index = start + 1;
		
		
		if(Search != null)
			sql = "select review.*,coffee.name from Review,Coffee where Review.cafeid = Coffee.cafeid and content like '%"+Search+"%'or review.regist_day like '%"+Search+"%'or name like'%"+Search+"%'or userid like '%"+Search+"%' order by num desc";
		else 
			sql = "select review.*,coffee.name from Review,Coffee where Review.cafeid = Coffee.cafeid order by num desc";
		
		ArrayList<Review> list = new ArrayList<Review>();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.absolute(index)) {
				Review Review = new Review();
				Review.setNum(rs.getInt(1));
				Review.setUserid(rs.getString(2));
				Review.setContent(rs.getString(3));
				Review.setRegist_day(rs.getString(4));
				Review.setCafeid(rs.getInt(5));
				Review.setCafename(rs.getString(6));
				list.add(Review);
				if (index < (start + 12) && index <= count) {
					index++;
				} else {
					break;
				}
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	//마이 리뷰 다음 페이지
	public boolean nextMyPage(int pageNum,String sessionId) { //매개변수에 세션 아이디 추가
		int count = getMyCount(sessionId);
		int start = (pageNum -1)*5;
		int index = start + 1;
		
		String sql = "select * from review where userid = ?"; // 5개만 출력
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, sessionId);
			rs = pstmt.executeQuery();	//결과 리턴
			while(rs.absolute(index)) {
				
				if (index < (start + 5) && index <= count) {
					index++;
				} else {
					break;
				}
				
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false; //결과가 없으면 false
	}
		
	// 해당 상품 리뷰 다음 페이지
	public boolean nextPage(int pageNum,String cafeid) { //매개변수에 카페 아이디 추가
		int count = getCafeCount(cafeid);
		int start = (pageNum -1)*5;
		int index = start + 1;
		
		String SQL = "select * from review where cafeid = ?"; // 5개만 출력
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, cafeid);
			rs = pstmt.executeQuery();	//결과 리턴
			while(rs.absolute(index)) {
				
				if (index < (start + 5) && index <= count) {
					index++;
				} else {
					break;
				}
				
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false; //결과가 없으면 false
	}
	
	
	// 관리자 리뷰 전체보기 다음 페이지
	public boolean nextPageAdmin(int pageNum) {
		int count = getAllCount();
		int start = (pageNum -1)*12;
		int index = start + 1;
		
		String SQL = "select * from review"; // 12개만 출력
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();	//결과 리턴
			while(rs.absolute(index)) {
				
				if (index < (start + 12) && index <= count) {
					index++;
				} else {
					break;
				}
				
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false; //결과가 없으면 false
	}
	
	
	//선택된 글 상세 내용 가져오기
	public Review getReviewByNum(int num, int page) {

		Review Review = null;

		String sql = "select review.*,coffee.name from Review,Coffee where Review.cafeid = Coffee.cafeid and num = ? ";

		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				Review = new Review();
				Review.setNum(rs.getInt(1));
				Review.setUserid(rs.getString(2));
				Review.setContent(rs.getString(3));
				Review.setRegist_day(rs.getString(4));
				Review.setCafeid(rs.getInt(5));
				Review.setCafename(rs.getString(6));
			}
			
			return Review;
		} catch (Exception ex) {
			System.out.println("getReviewByNum() 에러 : " + ex);
		} finally {
			closeAll();
		}
		return null;
	}
	
	//선택된 글 내용 수정하기
	public void updateReview(Review Review) {
		String sql = "update review set content = ? where num=?";

		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			conn.setAutoCommit(false);
			
			pstmt.setString(1, Review.getContent());
			pstmt.setInt(2, Review.getNum());
			
			pstmt.executeUpdate();
			conn.commit();
			
		} catch (Exception ex) {
			System.out.println("updateReview() 에러 : " + ex);
		} finally {
			closeAll();
		}
	}
	
	//선택된 글 삭제하기
	public void deleteReview(int num) {
		String sql = "delete from review where num=?";	

		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.executeUpdate();

		} catch (Exception ex) {
			System.out.println("deleteBoard() 에러 : " + ex);
		} finally {
			closeAll();
		}
	}
	
	//DB닫기 메소드
		public void closeAll() {
			try {
				if(rs != null) rs.close();
				if(conn != null) conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
	
	
	
}
