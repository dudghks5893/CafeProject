package cusvoice;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


// 게시판 서블릿 
public class CusvoiceController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String RequestURI = request.getRequestURI(); // 파일의 경로 path
		String contextPath = request.getContextPath(); // 프로젝트 경로 path
		// 총 파일경로에서 프로젝트 경로를 뺀 path
		// 예: http://localgost:8010/WebMarket (/BoardListAction.do)
		String command = RequestURI.substring(contextPath.length()); // substring: 잘라내기
		
		response.setContentType("text/html; charset=utf-8");
		request.setCharacterEncoding("utf-8");
		 		
		
		
			if (command.equals("/Cusvoice.jsp.Cusvoice")) { //고객의 소리  리스트
		 		RequestDispatcher rd = request.getRequestDispatcher("/Cusvoice.jsp");
				rd.forward(request, response);				
	 	} else if (command.equals("/CusvoiceEditAction.Cusvoice")) {//관리자가 고객의 소리 선택한 글 상세 페이지 가져오기
				requestCusvoiceEdit(request);
				RequestDispatcher rd = request.getRequestDispatcher("/CusvoiceEdit.Cusvoice");
				rd.forward(request, response);						
		} else if (command.equals("/CusvoiceEdit.Cusvoice")) { //관리자가 고객의 소리 선택한 글 상세 페이지 출력하기
				RequestDispatcher rd = request.getRequestDispatcher("/CusvoiceEdit.jsp");
				rd.forward(request, response);	
		} else if (command.equals("/UserCusvoiceEditAction.Cusvoice")) {//유저가 고객의 소리 선택한 글 상세 페이지 가져오기
				requestUserCusvoiceEdit(request);
				RequestDispatcher rd = request.getRequestDispatcher("/UserCusvoiceEdit.Cusvoice");
				rd.forward(request, response);						
		} else if (command.equals("/UserCusvoiceEdit.Cusvoice")) { //유저가 고객의 소리 선택한 글 상세 페이지 출력하기
				RequestDispatcher rd = request.getRequestDispatcher("/CusvoiceEdit.jsp");
				rd.forward(request, response);	
		} else if (command.equals("/CusvoiceUpdateAction.Cusvoice")) { //고객의 소리 선택한 글 수정
				requestCusvoiceUpdate(request);
				RequestDispatcher rd = request.getRequestDispatcher("/Cusvoice.jsp");
				rd.forward(request, response);
		} else if (command.equals("/CusvoiceDeleteAction.Cusvoice")) { //고객의 소리 선택한 글 삭제하기
				requestCusvoiceDelete(request);
				RequestDispatcher rd = request.getRequestDispatcher("/Cusvoice.jsp");
				rd.forward(request, response);				
		}  
	}


	//선택된 글 상세 페이지 가져오기
	public void requestCusvoiceEdit(HttpServletRequest request){
					
		CusvoiceDAO dao = new CusvoiceDAO();
		int num = Integer.parseInt(request.getParameter("num"));
		int pageNum = Integer.parseInt(request.getParameter("pageNum"));	
		
		Cusvoice Cusvoice = new Cusvoice();
		Cusvoice = dao.getCusvoiceByNum(num, pageNum);		
		
		request.setAttribute("num", num);		 
   		request.setAttribute("pageNum", pageNum); 
   		request.setAttribute("Cusvoice", Cusvoice);   									
	}
	//유저가 선택한 글 상세 페이지 가져오기
	public void requestUserCusvoiceEdit(HttpServletRequest request){
		
		CusvoiceDAO dao = new CusvoiceDAO();
		int num = Integer.parseInt(request.getParameter("num"));
		
		Cusvoice Cusvoice = new Cusvoice();
		Cusvoice = dao.getUserCusvoiceByNum(num);		
		
		request.setAttribute("num", num);		 
   		request.setAttribute("Cusvoice", Cusvoice);   									
	}
	
	
	//선택된 글 내용 수정하기
	public void requestCusvoiceUpdate(HttpServletRequest request){
					
		int num = Integer.parseInt(request.getParameter("num"));
		
		CusvoiceDAO dao = new CusvoiceDAO();		
		
		Cusvoice Cusvoice = new Cusvoice();		
		Cusvoice.setNum(num);
		Cusvoice.setTitle(request.getParameter("title"));	
		Cusvoice.setContent(request.getParameter("content"));	
		
		
		 dao.updateCusvoice(Cusvoice);
	}
	//선택된 글 삭제하기
	public void requestCusvoiceDelete(HttpServletRequest request){
					
		int num = Integer.parseInt(request.getParameter("num"));
		
		CusvoiceDAO dao = new CusvoiceDAO();
		dao.deleteCusvoice(num);					
	}
	
	
}
