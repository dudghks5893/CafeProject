package cusvoice;

import java.sql.*;
import java.util.ArrayList;


public class CusvoiceDAO {
	
	private Connection conn;
	private ResultSet rs;
	
	public CusvoiceDAO() { //생성자 생성시 DB연결 conn
		try {
			String url = "jdbc:mysql://localhost:3306/cafe?useSSL=false";
			String user = "root";
			String password = "1234";

			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection(url, user, password);	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// 관리자 고객의 소리 개수
	public int getNum() {
		String sql = "select count(*) from cusvoice";
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return rs.getInt(1);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1; //DB 오류
	}
	
	
	
	// 관리자 고객의 소리 다음 페이지
	public boolean nextPage(int pageNum) {
		int count = getNum();
		int start = (pageNum -1)*5;
		int index = start + 1;
		
		String SQL = "select * from cusvoice"; // 5개만 출력
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs = pstmt.executeQuery();	//결과 리턴
			while(rs.absolute(index)) {
				
				if (index < (start + 5) && index <= count) {
					index++;
				} else {
					break;
				}
				
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false; //결과가 없으면 false
	}
	

	
	// 관리자가  선택한 글 상세 내용 가져오기
	public Cusvoice getCusvoiceByNum(int num, int page) {

		Cusvoice Cusvoice = null;

		String sql = "select * from Cusvoice where num = ? ";

		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				Cusvoice = new Cusvoice();
				Cusvoice.setNum(rs.getInt(1));
				Cusvoice.setTitle(rs.getString(2));
				Cusvoice.setContent(rs.getString(3));
				Cusvoice.setRegist_day(rs.getString(4));
				Cusvoice.setUserid(rs.getString(5));
			}
			
			return Cusvoice;
		} catch (Exception ex) {
			System.out.println("getCusvoiceByNum() 에러 : " + ex);
		} finally {
			closeAll();
		}
		return null;
	}
	

	
	//관리자 고객의 소리 리스트
	public ArrayList<Cusvoice> getAllCusvoice(int pageNum){
		int count = getNum();
		int start = (pageNum -1)*5;
		int index = start + 1;
		
		String sql = "select * from Cusvoice order by num desc"; // 5개만 출력
		
		ArrayList<Cusvoice> list = new ArrayList<Cusvoice>();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.absolute(index)) {
				Cusvoice Review = new Cusvoice();
				Review.setNum(rs.getInt(1));
				Review.setTitle(rs.getString(2));
				Review.setContent(rs.getString(3));
				Review.setRegist_day(rs.getString(4));
				Review.setUserid(rs.getString(5));
				list.add(Review);
				
				if (index < (start + 5) && index <= count) {
					index++;
				} else {
					break;
				}
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	//유저 본인이 쓴 고객의 소리 
	public ArrayList<Cusvoice> getUserCusvoice(String sessionId){ // 매개변수에 세션아이디 추가해야함
		String sql = "select * from Cusvoice where userid=? order by num desc";
		
		ArrayList<Cusvoice> list = new ArrayList<Cusvoice>();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1,sessionId);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Cusvoice Review = new Cusvoice();
				Review.setNum(rs.getInt(1));
				Review.setTitle(rs.getString(2));
				Review.setContent(rs.getString(3));
				Review.setRegist_day(rs.getString(4));
				Review.setUserid(rs.getString(5));
				list.add(Review);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	// 유저가  선택한 글 상세 내용 가져오기
	public Cusvoice getUserCusvoiceByNum(int num) {

		Cusvoice Cusvoice = null;

		String sql = "select * from Cusvoice where num = ? ";

		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();

			if (rs.next()) {
				Cusvoice = new Cusvoice();
				Cusvoice.setNum(rs.getInt(1));
				Cusvoice.setTitle(rs.getString(2));
				Cusvoice.setContent(rs.getString(3));
				Cusvoice.setRegist_day(rs.getString(4));
				Cusvoice.setUserid(rs.getString(5));
			}
			
			return Cusvoice;
		} catch (Exception ex) {
			System.out.println("getUserCusvoiceByNum() 에러 : " + ex);
		} finally {
			closeAll();
		}
		return null;
	}
	
	//고객의 소리 선택된 글 내용 수정하기
	public void updateCusvoice(Cusvoice Cusvoice) {
		String sql = "update Cusvoice set title = ?, content = ? where num=?";

		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			conn.setAutoCommit(false);
			
			pstmt.setString(1, Cusvoice.getTitle());
			pstmt.setString(2, Cusvoice.getContent());
			pstmt.setInt(3, Cusvoice.getNum());
			
			pstmt.executeUpdate();
			conn.commit();
			
		} catch (Exception ex) {
			System.out.println("updateCusvoice() 에러 : " + ex);
		} finally {
			closeAll();
		}
	}
	
	//고객의 소리 선택된 글 삭제하기
	public void deleteCusvoice(int num) {
		String sql = "delete from Cusvoice where num=?";	

		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.executeUpdate();

		} catch (Exception ex) {
			System.out.println("deleteCusvoice() 에러 : " + ex);
		} finally {
			closeAll();
		}
	}
	
	
	
	
	
	
	//DB닫기 메소드
		public void closeAll() {
			try {
				if(rs != null) rs.close();
				if(conn != null) conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		}
	
	
	
}
