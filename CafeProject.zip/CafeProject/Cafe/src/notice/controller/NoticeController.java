package notice.controller;


import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import notice.model.NoticeDAO;
import notice.model.NoticeDTO;

//@WebServlet("/NoticeController")
public class NoticeController extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	static final int LISTCOUNT = 10;
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String RequestURI = request.getRequestURI();
		String contextPath = request.getContextPath();
		//String query = request.getQueryString();
		//String command = request.getQueryString();
		String command = RequestURI.substring(contextPath.length());
		//System.out.println("RequestURI : " + RequestURI);
		//System.out.println("contextPath : " + contextPath);
		
		//String command = request.getParameter("command");
		//String pageNum = request.getParameter("pageNum");
		
		//System.out.println("command : " + command);
		//System.out.println("pageNum : " + pageNum);
		//System.out.println("query : " + query);
		
		
		response.setContentType("text/html charset=utf-8");
		request.setCharacterEncoding("utf-8");
		
		if(command.equals("/NoticeListAction.do")) {
			requestNoticeList(request);
			RequestDispatcher rd = request.getRequestDispatcher("./notice/notice.jsp");
			rd.forward(request, response);
			//System.out.println(request);
			//response.sendRedirect("./notice/notice.jsp");
		}else if(command.equals("/NoticeWriteForm.do")) {
			requestLoginName(request);
			//System.out.println("1.request : " +request);
			//System.out.println(response);
			RequestDispatcher rd = request.getRequestDispatcher("./notice/writeNotice.jsp");
			rd.forward(request, response);
			//System.out.println("2.request : " +request);
			//System.out.println("response : " +response);
		}else if(command.equals("/NoticeWriteAction.do")) {
			requestNotieWrite(request);
			RequestDispatcher rd = request.getRequestDispatcher("/NoticeListAction.do");
			rd.forward(request, response);
		}else if(command.equals("/NoticeViewAction.do")) {
			requestNoticeView(request);
			RequestDispatcher rd = request.getRequestDispatcher("/NoticeView.do");
			rd.forward(request, response);
		}else if(command.equals("/NoticeView.do")) {
			RequestDispatcher rd = request.getRequestDispatcher("./notice/view.jsp");
			rd.forward(request, response);
		}else if(command.equals("/NoticeUpdateAction.do")) {
			requestNoticeUpdate(request);
			RequestDispatcher rd = request.getRequestDispatcher("/NoticeListAction.do");
			rd.forward(request, response);
		}else if(command.equals("/NoticeDeleteAction.do")) {
			requestNoticeDelete(request);
			RequestDispatcher rd = request.getRequestDispatcher("/NoticeListAction.do");
			rd.forward(request, response);
		}
	}
	//틍록된 글 목록 갸져오기
	public void requestNoticeList(HttpServletRequest request) {
		NoticeDAO dao = NoticeDAO.getInstance();
		List<NoticeDTO> noticelist = new ArrayList<NoticeDTO>();
		
		int pageNum = 1;
		int limit = LISTCOUNT;
		
		if(request.getParameter("pageNum") != null)
			pageNum = Integer.parseInt(request.getParameter("pageNum"));
		
		String items = request.getParameter("items");
		String text = request.getParameter("text");
		
		int total_record = dao.getListCount(items, text);
		noticelist = dao.getNoticeList(pageNum, limit, items, text);
		
		int total_page;
		
		if(total_record % limit == 0) {
			total_page = total_record/limit;
			Math.floor(total_page);
		}else {
			total_page = total_record/limit;
			Math.floor(total_page);
			total_page = total_page + 1;
		}
		
		request.setAttribute("pageNum", pageNum);
		request.setAttribute("total_page", total_page);
		request.setAttribute("total_record", total_record);
		request.setAttribute("noticelist", noticelist);
		
	}
	//인증된 사용자명 가져오기
	public void requestLoginName(HttpServletRequest request) {
		String name =  request.getParameter("id");
		request.setAttribute("name", name);
	}
	
	//새로운 글 등록하기
	public void requestNotieWrite(HttpServletRequest request) {
		NoticeDAO dao = NoticeDAO.getInstance();
		
		NoticeDTO notice = new NoticeDTO();
		notice.setUserId(request.getParameter("id"));
		notice.setTitle(request.getParameter("subject"));
		notice.setContent(request.getParameter("content"));
		notice.setFileName(request.getParameter("fileName"));
		
		java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat("yyyy/MM/dd(HH:mm:ss)");
		String regist_day = formatter.format(new java.util.Date()); 
		
		notice.setRegist_day(regist_day);
		
		dao.insertNotice(notice);
	}
	//선택된 글 상세 페이지 가져오기
	public void requestNoticeView(HttpServletRequest request) {
		NoticeDAO dao = NoticeDAO.getInstance();
		int num = Integer.parseInt(request.getParameter("num"));
		int pageNum = Integer.parseInt(request.getParameter("pageNum"));
		
		NoticeDTO notice = new NoticeDTO();
		notice = dao.getNoticeByNum(num, pageNum);
		
		request.setAttribute("num", num);
		request.setAttribute("page", pageNum);
		request.setAttribute("notice", notice);
	}
	//선택된 글 내용 수정하기
	public void requestNoticeUpdate(HttpServletRequest request) {
		int num = Integer.parseInt(request.getParameter("num"));
		int pageNum = Integer.parseInt(request.getParameter("pageNum"));
		
		NoticeDAO dao = NoticeDAO.getInstance();
		
		NoticeDTO notice = new NoticeDTO();
		notice.setNum(num);
		notice.setUserId(request.getParameter("name"));
		notice.setTitle(request.getParameter("subject"));
		notice.setContent(request.getParameter("content"));
		notice.setFileName(request.getParameter("fileName"));
		
		java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat("yyyy/MM/dd(HH:mm:ss)");
		String regist_day = formatter.format(new java.util.Date()); 
		
		notice.setRegist_day(regist_day);
		
		dao.updateNotice(notice);
	}
	
	public void requestNoticeDelete(HttpServletRequest request) {
		int num = Integer.parseInt(request.getParameter("num"));
		int pageNum = Integer.parseInt(request.getParameter("pageNum"));
		
		NoticeDAO dao = NoticeDAO.getInstance();
		dao.deleteNotice(num);
		
	}
}
