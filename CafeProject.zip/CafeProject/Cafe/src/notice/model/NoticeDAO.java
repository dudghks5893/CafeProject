package notice.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import notice.database.DBConnection;



public class NoticeDAO {
	private static NoticeDAO instance;
	
	private Connection conn = null;
	private PreparedStatement pstmt = null;
	private ResultSet rs = null;
	
	private NoticeDAO() {
		
	}
	
	public static NoticeDAO getInstance() {
		if(instance == null)		//instance객체가 없으면 새로 만들고 
			instance = new NoticeDAO();
		return instance;
	}
	//notice 테이블의 레코드 개수
	public int getListCount(String items, String text) {
		int x = 0;
		
		String sql;
		try {
			conn = DBConnection.getConnection();
		
		if(items == null && text ==null) {
			sql = "SELECT count(*) FROM notie";
			pstmt = conn.prepareStatement(sql);
		}else {
			sql = "SELECT count(*) FROM notie where " + items + " LIKE ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%"+text+"%");
		}
			rs = pstmt.executeQuery();
			
			if(rs.next())
				x = rs.getInt(1);
		} catch (Exception ex) {
			System.out.println("getListCount() 에러: " + ex);
			ex.printStackTrace();
		} finally {
			closeAll();
		}
		return x;
	}
	//notice 테이블의 레코드 가져오기, 화면에서 항상 10개의 게시글만 보여지기 때문에 5개만 리턴한다.
	public ArrayList<NoticeDTO> getNoticeList(int page, int limit, String items, String text){
		//총 게시글 수
		int total_record = getListCount(items, text);
		int start = (page-1) * limit;	//페이지에 따라서 보여줄 첫번째 게시글 번호
		int index = start +1;			//0번은 없어서 +1
		
		String sql;
		try {
			conn = DBConnection.getConnection();
			
		if(items ==null & text == null) {
			sql = "SELECT * FROM notie ORDER BY num DESC";
			pstmt = conn.prepareStatement(sql);
		}else {
			sql = "SELECT * FROM notie where " + items + " like ? ORDER BY num DESC";
									 //where      title   like '%     삼성         %' order by num desc;
		//System.out.println(sql);
		//리스트 생성
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%"+text+"%");
			}rs = pstmt.executeQuery();
			
			ArrayList<NoticeDTO> list = new ArrayList<NoticeDTO>();
			while(rs.absolute(index)) {
				NoticeDTO notice = new NoticeDTO();
				notice.setNum(rs.getInt("num"));
				notice.setTitle(rs.getString("title"));
				notice.setContent(rs.getString("content"));
				notice.setRegist_day(rs.getString("regist_day"));
				notice.setFileName(rs.getString("fileName"));
				notice.setUserId(rs.getString("userid"));
				list.add(notice);
				
				//인덱스 <(0+5) -> 최대 리스트에 5개 까지 담을 수 있음
				if(index < (start + limit) && index <= total_record)
					index++;
				else
					break;
			}
			return list;
		} catch (Exception ex) {
			System.out.println("getNoticeList() 에러 : " + ex);
		}finally {
			closeAll();
		}return null;
	}
	//user테이블에서 인증된 id가져오기
	//필요없음
	
	//notice테이블에 새로운 글 삽입하기
	public void insertNotice(NoticeDTO notice) {
		try {
			conn = DBConnection.getConnection();
			
			String sql = "INSERT INTO notie values(?,?,?,?,?,?)";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, notice.getNum());
			pstmt.setString(2, notice.getTitle());
			pstmt.setString(3, notice.getContent());
			pstmt.setString(4, notice.getRegist_day());
			pstmt.setString(5, notice.getFileName());
			pstmt.setString(6, notice.getUserId());
			pstmt.executeUpdate();
		} catch (Exception ex) {
			System.out.println("insertNotice() 에러 : " + ex);
		}finally {
			closeAll();
		}
	}
	public NoticeDTO getNoticeByNum(int num, int page) {
		NoticeDTO notice = null;
		
		String sql = "SELECT * FROM notie WHERE num = ?";
	
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			
			if(rs.next()) {
				notice = new NoticeDTO();
				notice.setNum(rs.getInt("num"));
				notice.setTitle(rs.getString("title"));
				notice.setContent(rs.getString("content"));
				notice.setRegist_day(rs.getString("regist_day"));
				notice.setFileName(rs.getString("fileName"));
				notice.setUserId(rs.getString("userid"));
			}
			return notice;
			
		} catch (Exception ex) {
			System.out.println("getNoticeByNum() 에러 : " + ex);
		}finally {
			closeAll();
		} 
		return null;
	}
	
	public void updateNotice(NoticeDTO notice) {
		
		try {
			String sql = "UPDATE notie SET userid=?, title=?, content=?, fileName=? WHERE num=?";
			
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			
			conn.setAutoCommit(false);
			
			pstmt.setString(1, notice.getUserId());
			pstmt.setString(2, notice.getTitle());
			pstmt.setString(3, notice.getContent());
			pstmt.setString(4, notice.getFileName());
			pstmt.setInt(5, notice.getNum());
			
			pstmt.executeUpdate();
			conn.commit();
			
		} catch (Exception ex) {
			System.out.println("updateNotice() 에러 : " + ex);
		}finally {
			closeAll();	
		}
	}
	public void deleteNotice(int num) {
		String sql = "DELETE FROM notie WHERE num = ?";
		try {
			conn = DBConnection.getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			pstmt.executeUpdate();
		} catch (Exception ex) {
			System.out.println("deleteNotice() 에러 : " + ex);
		}finally {
			closeAll();	
		}
	}
	// db 닫기
	private void closeAll() {
		try {		
			if (rs != null) rs.close();
			if (pstmt != null) pstmt.close();				
			if (conn != null) conn.close();
		} catch (Exception ex) {
			throw new RuntimeException(ex.getMessage());
		}
	}
		
}
