package bbs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class BbsDAO {
	   
	    Connection conn;
	    ResultSet rs;
	   
	    public BbsDAO() {
			try {
				String dbURL = "jdbc:mysql://localhost:3306/cafe?useSSL=false";
				String dbID = "root";
				String dbPassword = "1234";
				Class.forName("com.mysql.jdbc.Driver");
				conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	 
	 //DB 닫는 메소드
	 public void closeAll() {
		 try {
			if(rs != null) rs.close();
			if (conn != null) conn.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	 }
	 
	 //현재 날짜를 나타내주는 메소드 
	 public String getDate() {
		 String sql ="select now()";
		 try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				return rs.getString(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		 return ""; //데이터 베이스 오류
		 
	 }
	 
	 //가장 최근에 적은 글의 num +1을 리턴하는 메소드
	 public int getNext() {
		 //내림차순으로 가장 마지막에 쓰인 글 번호를 가져옴
		 String sql ="select num from notie order by num desc";
		 try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if(rs.next()) {
				//마지막 게시글에 +1을 해서 그 다음 게시글의 번호를 매겨줌 
				return rs.getInt(1) +1;
			}
			return 1; //첫 번째 게시물인 경우
		} catch (Exception e) {
			e.printStackTrace();
		}
		 return -1; //데이터 베이스 오류
	 }
	 
	 //글작성 메소드
	 public int write(String title, String userId, String content, String fileName){
		 
		 
		 
		 java.text.SimpleDateFormat formatter = new java.text.SimpleDateFormat("yyyy/MM/dd(HH:mm:ss)");
		 String num = "";

		 String regist_day = formatter.format(new java.util.Date());
		 String fileName1 = "파일이름";
		 
		 String sql ="insert into notie values (?,?,?,?,?,?)";
		 
		 
		 int next = getNext();
		 String now = getDate();
		 
		 try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, num); //게시글번호
			pstmt.setString(2, title);
			pstmt.setString(3, content);
			pstmt.setString(4, regist_day); //현재 날짜
			pstmt.setString(5, fileName);
			pstmt.setString(6, userId);
			return pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			closeAll();
		}
		 return -1; //데이터 베이스 오류
	 }
	 
	 
	 
	
}
